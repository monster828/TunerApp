function ToTuner(button){
    console.log(button);
    window.location.href = `./tuner.html?data=${button}`;
}